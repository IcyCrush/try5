document.addEventListener("DOMContentLoaded", function() {
    // Sample data from your script file
    var data = [
        { UnderwriterID: "12345", Name: "Alice", location: "31-01-2000", password: "abcdefg" },
        { UnderwriterID: "12346", Name: "Alice", location: "01-01-2000", password: "abcdefg" },
        { UnderwriterID: "12347", Name: "Alice", location: "01-01-2000", password: "abcdefg" }
        // Add more data as needed
    ];

    // Function to populate the table with data
    function populateTable(data) {
        var tbody = document.querySelector("#dataTable tbody");

        data.forEach(function(item) {
            var row = document.createElement("tr");
            row.innerHTML = `<td>${item.UnderwriterID}</td><td>${item.Name}</td><td>${item.location}</td><td>${item.password}</td>`;
            
            // Creating buttons for each row
            var removeBtnCell = document.createElement("td");
        var editBtnCell = document.createElement("td");

        // Create remove button
        var removeBtn = document.createElement("button");
        removeBtn.textContent = "Remove";
        removeBtn.addEventListener("click", function() {
            // Remove the row when the remove button is clicked
            row.remove();
        });

        // Create edit button
        var editBtn = document.createElement("button");
        editBtn.textContent = "Edit Password";
        editBtn.addEventListener("click", function() {
            // Implement edit functionality here
            // For demonstration, you can alert the current location
            alert("Editing location: " + item.location);
        });

        // Append buttons to respective cells
        removeBtnCell.appendChild(removeBtn);
        editBtnCell.appendChild(editBtn);

        // Append cells to the row
        row.appendChild(removeBtnCell);
        row.appendChild(editBtnCell);

        // Append the row to the table body
        tbody.appendChild(row);
        });
    }

    // Call the function to populate the table with data
    populateTable(data);
});
